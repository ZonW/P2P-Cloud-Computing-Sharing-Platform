const usersData = require('./users');
const productsData = require('./products');

module.exports = {
  users: usersData,
  products: productsData
};
